package com.hong.blog.model;

public enum RoleType {
	USER, ADMIN
}
